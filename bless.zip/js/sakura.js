$(document).ready(function(){
     $('#imageoption').attr('src','fly.html');
   });